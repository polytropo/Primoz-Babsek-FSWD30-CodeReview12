<!doctype html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="<?php bloginfo('description'); ?>">
    <title>
      <?php bloginfo('name'); ?> | 
      <?php is_front_page() ? bloginfo('description') : wp_title(); ?>
    </title>

    <!-- Bootstrap core CSS -->
    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <?php wp_head(); ?>

  </head>

  <body>

    <div class="blog-masthead">
      
        <nav class="navbar navbar-expand-md navbar-light bg-dark" role="navigation">
          <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <!-- <a class="navbar-brand" href="#">Navbar</a> -->
                <?php
                wp_nav_menu( array(
                    'theme_location'    => 'primary',
                    'depth'             => 2,
                    'container'         => 'div',
                    'container_class'   => 'collapse navbar-collapse',
                    'container_id'      => 'bs-example-navbar-collapse-1',
                    'menu_class'        => 'nav navbar-nav',
                    'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
                    'walker'            => new WP_Bootstrap_Navwalker()
            ) );
                ?>
            </div>
        </nav>
    </div>
        

	<section class="showcase">
      <div class="container">
        <h1>Mount Everest</h1>
        <p> We are the best travel agency in the world!
        </p>
          <a class="btn btn-primary btn-lg href=" href="blog">
              Check our blogs</a>
      </div>
    </section>
    <section class="boxes">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <div class="box">
              <i class="fa fa-plane" aria-hidden="true"></i>
              <h3>Lorem ipsum Dolor</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi, voluptatem?</p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="box">
              <i class="fa fa-ship aria-hidden="true"></i>
              <h3>Lorem ipsum Dolor</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi, voluptatem?</p>
            </div>
          </div>
          <div class="col-md-4">
            <div class="box">
              <i class="fa fa-bus" aria-hidden="true"></i>
              <h3>Lorem ipsum Dolor</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi, voluptatem?</p>
            </div>
          </div>
        </div>
    </section>
    <footer class="blog-footer">
      <p>&copy; <?php echo Date('Y'); ?> - <?php bloginfo('name'); ?></p>
      <p>  
        <a href="#">Back to top</a>
      </p>
    </footer>
    
    <?php wp_footer(); ?>
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
   
    <!-- <script src="../../../../assets/js/vendor/popper.min.js"></script> -->
    <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
   
  </body>
</html>